const remote = require("electron").remote;

const { toggleAppMenu } = remote.require("./main/menu");
toggleAppMenu(1);

















