const { autoUpdater } = require('electron-updater');
//Check for updates and notify user
autoUpdater.checkForUpdatesAndNotify();
