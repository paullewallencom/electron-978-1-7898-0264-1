test("Check DOM Window", () => {
  expect(window).toBeDefined();
});

//Other DOM manipulation tests

